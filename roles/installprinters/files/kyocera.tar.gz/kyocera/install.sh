#!/bin/bash
if [ ! -d /usr/share/cups/model ]; then
 sudo mkdir /usr/share/cups/model
fi
if [ ! -d /usr/share/cups/model/Kyocera ]; then
sudo mkdir /usr/share/cups/model/Kyocera
fi
sudo cp Kyocera_FS-1040GDI.ppd /usr/share/cups/model/Kyocera/Kyocera_FS-1040GDI.ppd
sudo cp Kyocera_FS-1020MFPGDI.ppd /usr/share/cups/model/Kyocera/Kyocera_FS-1020MFPGDI.ppd
sudo cp Kyocera_FS-1025MFPGDI.ppd /usr/share/cups/model/Kyocera/Kyocera_FS-1025MFPGDI.ppd
sudo cp Kyocera_FS-1120MFPGDI.ppd /usr/share/cups/model/Kyocera/Kyocera_FS-1120MFPGDI.ppd
sudo cp Kyocera_FS-1125MFPGDI.ppd /usr/share/cups/model/Kyocera/Kyocera_FS-1125MFPGDI.ppd
sudo cp Kyocera_FS-1060DNGDI.ppd /usr/share/cups/model/Kyocera/Kyocera_FS-1060DNGDI.ppd 
sudo cp rastertokpsl /usr/lib/cups/filter/rastertokpsl
if [ -f /usr/lib/cups/filter/rastertokpsl ] && [ -f /usr/share/cups/model/Kyocera/Kyocera_FS-1040GDI.ppd ] && [ -f /usr/share/cups/model/Kyocera/Kyocera_FS-1060DNGDI.ppd ] && [ -f /usr/share/cups/model/Kyocera/Kyocera_FS-1020MFPGDI.ppd ] && [ -f /usr/share/cups/model/Kyocera/Kyocera_FS-1025MFPGDI.ppd ] && [ -f /usr/share/cups/model/Kyocera/Kyocera_FS-1120MFPGDI.ppd ] && [ -f /usr/share/cups/model/Kyocera/Kyocera_FS-1125MFPGDI.ppd ]; then
echo "Installation completed"
else
echo "Installation failed"
fi



